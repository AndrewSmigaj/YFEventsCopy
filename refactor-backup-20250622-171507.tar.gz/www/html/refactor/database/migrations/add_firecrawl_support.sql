-- Add Firecrawl support to YFEvents
-- Date: 2025-06-18

-- Add scraper type to calendar_sources
ALTER TABLE calendar_sources 
ADD COLUMN scraper_type ENUM('traditional', 'intelligent', 'firecrawl') 
DEFAULT 'traditional' 
COMMENT 'Type of scraper to use for this source'
AFTER source_type;

-- Add rate limiting configuration
ALTER TABLE calendar_sources
ADD COLUMN rate_limit_config JSON DEFAULT NULL 
COMMENT 'Rate limiting settings for this source'
AFTER configuration;

-- Add scraping metrics table
CREATE TABLE IF NOT EXISTS scraping_metrics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    source_id INT NOT NULL,
    scrape_date DATETIME NOT NULL,
    events_found INT DEFAULT 0,
    events_created INT DEFAULT 0,
    events_updated INT DEFAULT 0,
    duration_seconds FLOAT,
    status ENUM('success', 'rate_limited', 'error', 'partial') DEFAULT 'success',
    error_message TEXT,
    memory_usage INT COMMENT 'Memory usage in bytes',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_id) REFERENCES calendar_sources(id) ON DELETE CASCADE,
    INDEX idx_source_date (source_id, scrape_date),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Track scraping performance and success metrics';

-- Add Firecrawl configuration table
CREATE TABLE IF NOT EXISTS firecrawl_config (
    id INT PRIMARY KEY AUTO_INCREMENT,
    config_key VARCHAR(50) UNIQUE NOT NULL,
    config_value TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_key (config_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Firecrawl API configuration and settings';

-- Insert default Firecrawl configuration
INSERT INTO firecrawl_config (config_key, config_value, description) VALUES
('api_endpoint', 'https://api.firecrawl.dev/v0', 'Firecrawl API base URL'),
('timeout', '30', 'Request timeout in seconds'),
('max_retries', '3', 'Maximum retry attempts for failed requests'),
('rate_limit_delay', '2', 'Seconds between requests'),
('max_events_per_scrape', '50', 'Maximum events to retrieve per scrape'),
('user_agent', 'YFEvents/2.0 (https://yakimafinds.com)', 'User agent for requests');

-- Add sample Eventbrite source with Firecrawl
INSERT INTO calendar_sources (
    source_name,
    source_url,
    source_type,
    scraper_type,
    configuration,
    rate_limit_config,
    is_active,
    created_at
) VALUES (
    'Eventbrite - Yakima (Firecrawl)',
    'https://www.eventbrite.com/d/wa--yakima/events/',
    'html',
    'firecrawl',
    JSON_OBJECT(
        'location', 'Yakima',
        'state', 'wa',
        'categories', JSON_ARRAY('music', 'arts', 'food-drink', 'community'),
        'max_pages', 3
    ),
    JSON_OBJECT(
        'requests_per_minute', 30,
        'delay_seconds', 2,
        'backoff_multiplier', 2
    ),
    0, -- Inactive by default until API key is configured
    NOW()
);

-- Add index for scraper type queries
ALTER TABLE calendar_sources ADD INDEX idx_scraper_type (scraper_type, is_active);