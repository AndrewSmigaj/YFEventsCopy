Your version of Internet Explorer is not longer supported. Please [upgrade your browser](https://www.eventbrite.com/support/articles/en_US/Troubleshooting/how-to-troubleshoot-internet-browser-issues).


[_Eventbrite_](https://www.eventbrite.com/) [_Eventbrite_](https://www.eventbrite.com/)

- [Find my tickets](https://www.eventbrite.com/signin/signup/?referrer=%2Fmytickets)
- [Log In](https://www.eventbrite.com/signin/?referrer=%2Fd%2Fwa--yakima%2Fevents%2F)
- [Sign Up](https://www.eventbrite.com/signin/signup/?referrer=%2Fd%2Fwa--yakima%2Fevents%2F)
  - [Find Events](https://www.eventbrite.com/d/local/events/)
  - Create Events
    - Solutions
      Solutions      - [Event Ticketing](https://www.eventbrite.com/organizer/features/sell-tickets/)
      - [Event Marketing Platform](https://www.eventbrite.com/organizer/features/event-marketing-platform/)
      - [Eventbrite Ads](https://www.eventbrite.com/organizer/features/eventbrite-ads/)
      - [Payments](https://www.eventbrite.com/organizer/features/event-payment/)
    - Industry
      Industry      - [Music](https://www.eventbrite.com/organizer/event-industry/music/)
      - [Food & Beverage](https://www.eventbrite.com/organizer/event-industry/food-drink-event-ticketing/)
      - [Performing Arts](https://www.eventbrite.com/organizer/event-industry/performing-arts/)
      - [Charity & Causes](https://www.eventbrite.com/organizer/event-type/npo/)
      - [Retail](https://www.eventbrite.com/organizer/event-format/host-retail-events/)
    - Event Types
      Event Types      - [Concerts](https://www.eventbrite.com/organizer/event-type/music-venues/)
      - [Classes & Workshops](https://www.eventbrite.com/organizer/event-type/create-a-workshop/)
      - [Festivals & Fairs](https://www.eventbrite.com/organizer/event-type/festival-solutions/)
      - [Conferences](https://www.eventbrite.com/organizer/event-type/conferences/)
      - [Corporate Events](https://www.eventbrite.com/organizer/event-type/eventbrite-for-business/)
      - [Online Events](https://www.eventbrite.com/organizer/event-type/virtual-events-platform/)
    - Blog
      Blog      - [Tips & Guides](https://www.eventbrite.com/blog/category/tips-and-guides/)
      - [News & Trends](https://www.eventbrite.com/blog/category/news-and-trends/)
      - [Community](https://www.eventbrite.com/blog/category/community/)
      - [Tools & Features](https://www.eventbrite.com/blog/category/tools-and-features/)
  - [Organizer Resource Hub](https://www.eventbrite.com/resources/)
  - [Create Events](https://www.eventbrite.com/organizer/overview/)
  - [Contact Sales](https://www.eventbrite.com/organizer/contact-sales/)
  - [Get Started](https://www.eventbrite.com/signin/signup/?referrer=/manage/events/create/)
  - Help Center
    - [Help Center](https://www.eventbrite.com/help/en-us/)
    - [Find your tickets](https://www.eventbrite.com/help/en-us/articles/319355/where-are-my-tickets/)
    - [Contact your event organizer](https://www.eventbrite.com/help/en-us/articles/647151/how-to-contact-the-event-organizer/)

Search events

* * *

_Choose a location_

autocomplete

- [Contact Sales](https://www.eventbrite.com/organizer/contact-sales/)
- [Create Events](https://www.eventbrite.com/organizer/overview/)
- Help Center

- [Find my tickets](https://www.eventbrite.com/signin/signup/?referrer=%2Fmytickets)
- [Log In](https://www.eventbrite.com/signin/?referrer=%2Fd%2Fwa--yakima%2Fevents%2F)
- [Sign Up](https://www.eventbrite.com/signin/signup/?referrer=%2Fd%2Fwa--yakima%2Fevents%2F)

- [Find Events](https://www.eventbrite.com/d/local/events/)
- Create Events
  - Solutions
    Solutions    - [Event Ticketing](https://www.eventbrite.com/organizer/features/sell-tickets/)
    - [Event Marketing Platform](https://www.eventbrite.com/organizer/features/event-marketing-platform/)
    - [Eventbrite Ads](https://www.eventbrite.com/organizer/features/eventbrite-ads/)
    - [Payments](https://www.eventbrite.com/organizer/features/event-payment/)
  - Industry
    Industry    - [Music](https://www.eventbrite.com/organizer/event-industry/music/)
    - [Food & Beverage](https://www.eventbrite.com/organizer/event-industry/food-drink-event-ticketing/)
    - [Performing Arts](https://www.eventbrite.com/organizer/event-industry/performing-arts/)
    - [Charity & Causes](https://www.eventbrite.com/organizer/event-type/npo/)
    - [Retail](https://www.eventbrite.com/organizer/event-format/host-retail-events/)
  - Event Types
    Event Types    - [Concerts](https://www.eventbrite.com/organizer/event-type/music-venues/)
    - [Classes & Workshops](https://www.eventbrite.com/organizer/event-type/create-a-workshop/)
    - [Festivals & Fairs](https://www.eventbrite.com/organizer/event-type/festival-solutions/)
    - [Conferences](https://www.eventbrite.com/organizer/event-type/conferences/)
    - [Corporate Events](https://www.eventbrite.com/organizer/event-type/eventbrite-for-business/)
    - [Online Events](https://www.eventbrite.com/organizer/event-type/virtual-events-platform/)
  - Blog
    Blog    - [Tips & Guides](https://www.eventbrite.com/blog/category/tips-and-guides/)
    - [News & Trends](https://www.eventbrite.com/blog/category/news-and-trends/)
    - [Community](https://www.eventbrite.com/blog/category/community/)
    - [Tools & Features](https://www.eventbrite.com/blog/category/tools-and-features/)
- [Organizer Resource Hub](https://www.eventbrite.com/resources/)
- [Create Events](https://www.eventbrite.com/organizer/overview/)
- [Contact Sales](https://www.eventbrite.com/organizer/contact-sales/)
- [Get Started](https://www.eventbrite.com/signin/signup/?referrer=/manage/events/create/)
- Help Center
  - [Help Center](https://www.eventbrite.com/help/en-us/)
  - [Find your tickets](https://www.eventbrite.com/help/en-us/articles/319355/where-are-my-tickets/)
  - [Contact your event organizer](https://www.eventbrite.com/help/en-us/articles/647151/how-to-contact-the-event-organizer/)

1. [Home](https://www.eventbrite.com/)/
2. [United States](https://www.eventbrite.com/ttd/united-states/)/
3. [Things to do in Yakima](https://www.eventbrite.com/ttd/wa--yakima/)/
4. Events in Yakima

![Yakima](https://cdn.evbstatic.com/s3-build/fe/build/images/3f96dddb80dd0a06eb9e5836cc641f33-generic_2_desktop.webp)

# Best events in    Yakima

Looking for something to do in Yakima? Whether you're a local, new in town or just cruising through we've got loads of great tips and events. You can explore by location, what's popular, our top picks, free stuff... you got this. Ready?

autocomplete

autocomplete

## [Popular in Yakima](https://www.eventbrite.com/d/wa--yakima/all-events/)

[Explore more events](https://www.eventbrite.com/d/wa--yakima/all-events/)

[![She’s Crafty with Christin primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1053063063%2F211389770296%2F1%2Foriginal.20250614-144114?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.00380350194553&fp-y=0.00860894941634&s=ecdcd9975aa23f1a778707f043ffc124)](https://www.eventbrite.com/e/shes-crafty-with-christin-tickets-1361235745759?aff=ebdssbcitybrowse)

Sales end soon

[**She’s Crafty with Christin**](https://www.eventbrite.com/e/shes-crafty-with-christin-tickets-1361235745759?aff=ebdssbcitybrowse)

Tomorrow • 7:00 PM

Rooted Yakima Valley

Check ticket price on event

_Save this event: She’s Crafty with Christin__Share this event: She’s Crafty with Christin_

[![Learn How to Build A House primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1050286333%2F2679151205591%2F1%2Foriginal.20250610-224619?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=066bf671ee341eba38bd8e4dbaf10ba7)](https://www.eventbrite.com/e/learn-how-to-build-a-house-tickets-1407886890589?aff=ebdssbcitybrowse)

Sales end soon

[**Learn How to Build A House**](https://www.eventbrite.com/e/learn-how-to-build-a-house-tickets-1407886890589?aff=ebdssbcitybrowse)

Saturday • 10:00 AM

John L. Scott Real Estate \| Yakima

Check ticket price on event

_Save this event: Learn How to Build A House__Share this event: Learn How to Build A House_

[![Bridging Generational Gaps - YAKIMA, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F876616729%2F2404763187013%2F1%2Foriginal.20241017-024545?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=50586210b2c4bb481e1592e9b78a239a)](https://www.eventbrite.com/e/bridging-generational-gaps-yakima-wa-tickets-1204179576529?aff=ebdssbcitybrowse)

[**Bridging Generational Gaps - YAKIMA, WA**](https://www.eventbrite.com/e/bridging-generational-gaps-yakima-wa-tickets-1204179576529?aff=ebdssbcitybrowse)

Monday • 5:00 PM + 9 more

Yakima

Check ticket price on event

_Save this event: Bridging Generational Gaps - YAKIMA, WA__Share this event: Bridging Generational Gaps - YAKIMA, WA_

[![Kids Cooking Workshop: Basics of Cooking primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1048607583%2F163869624577%2F1%2Foriginal.20250609-000729?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=08680161567eaab602cf6e56357b28ad)](https://www.eventbrite.com/e/kids-cooking-workshop-basics-of-cooking-tickets-1405275459729?aff=ebdssbcitybrowse)

Going fast

[**Kids Cooking Workshop: Basics of Cooking**](https://www.eventbrite.com/e/kids-cooking-workshop-basics-of-cooking-tickets-1405275459729?aff=ebdssbcitybrowse)

Thu, Jun 26 • 1:00 PM

Healthy Eats Classroom

Check ticket price on event

_Save this event: Kids Cooking Workshop: Basics of Cooking__Share this event: Kids Cooking Workshop: Basics of Cooking_

[![How to buy a house in 2025 primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1047171813%2F519615972615%2F1%2Foriginal.20250606-032902?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.516949152542&fp-y=0.0955414012739&s=30b4ee89b0eb90f5a3369a625560f574)](https://www.eventbrite.com/e/how-to-buy-a-house-in-2025-tickets-1400812380539?aff=ebdssbcitybrowse)

[**How to buy a house in 2025**](https://www.eventbrite.com/e/how-to-buy-a-house-in-2025-tickets-1400812380539?aff=ebdssbcitybrowse)

Sat, Jun 28 • 10:00 AM

Yakima Association of REALTORS

Check ticket price on event

_Save this event: How to buy a house in 2025__Share this event: How to buy a house in 2025_

[![Hell’s Belles – Rock - AC/DC Tribute Band @Hoops primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1044100743%2F544198379297%2F1%2Foriginal.20250602-185216?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.518939393939&fp-y=0.238402061856&s=901666465f610f4c61dff80272fc2766)](https://www.eventbrite.com/e/hells-belles-rock-acdc-tribute-band-hoops-tickets-1393096793009?aff=ebdssbcitybrowse)

[**Hell’s Belles – Rock - AC/DC Tribute Band @Hoops**](https://www.eventbrite.com/e/hells-belles-rock-acdc-tribute-band-hoops-tickets-1393096793009?aff=ebdssbcitybrowse)

Sat, Jul 19 • 7:00 PM

Hoops

Check ticket price on event

_Save this event: Hell’s Belles – Rock - AC/DC Tribute Band @Hoops__Share this event: Hell’s Belles – Rock - AC/DC Tribute Band @Hoops_

[![Foundations of Digital Photography (6-Week Course) primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1044837803%2F137493871735%2F1%2Foriginal.20250603-150941?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.486742424242&fp-y=0.507434944238&s=699a7ef0538356bcd8967179c290e48b)](https://www.eventbrite.com/e/foundations-of-digital-photography-6-week-course-tickets-1393174926709?aff=ebdssbcitybrowse)

[**Foundations of Digital Photography (6-Week Course)**](https://www.eventbrite.com/e/foundations-of-digital-photography-6-week-course-tickets-1393174926709?aff=ebdssbcitybrowse)

Tue, Jul 22 • 6:00 PM

26 N 1st St suite a

Check ticket price on event

_Save this event: Foundations of Digital Photography (6-Week Course)__Share this event: Foundations of Digital Photography (6-Week Course)_

[![United in Hope, Together We Rise: WSCADV 2025 Conference primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1031093433%2F40101533418%2F1%2Foriginal.20250514-202704?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.498106060606&fp-y=0.356343283582&s=6274ffc98afca05c09307e21ea511d2e)](https://www.eventbrite.com/e/united-in-hope-together-we-rise-wscadv-2025-conference-registration-1307303673479?aff=ebdssbcitybrowse)

[**United in Hope, Together We Rise: WSCADV 2025 Conference**](https://www.eventbrite.com/e/united-in-hope-together-we-rise-wscadv-2025-conference-registration-1307303673479?aff=ebdssbcitybrowse)

Yakima Convention Center

Check ticket price on event

_Save this event: United in Hope, Together We Rise: WSCADV 2025 Conference__Share this event: United in Hope, Together We Rise: WSCADV 2025 Conference_

[![She’s Crafty with Christin primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1053063063%2F211389770296%2F1%2Foriginal.20250614-144114?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.00380350194553&fp-y=0.00860894941634&s=ecdcd9975aa23f1a778707f043ffc124)](https://www.eventbrite.com/e/shes-crafty-with-christin-tickets-1361235745759?aff=ebdssbcitybrowse)

Sales end soon

[**She’s Crafty with Christin**](https://www.eventbrite.com/e/shes-crafty-with-christin-tickets-1361235745759?aff=ebdssbcitybrowse)

Tomorrow • 7:00 PM

Rooted Yakima Valley

Check ticket price on event

_Save this event: She’s Crafty with Christin__Share this event: She’s Crafty with Christin_

[![Learn How to Build A House primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1050286333%2F2679151205591%2F1%2Foriginal.20250610-224619?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=066bf671ee341eba38bd8e4dbaf10ba7)](https://www.eventbrite.com/e/learn-how-to-build-a-house-tickets-1407886890589?aff=ebdssbcitybrowse)

Sales end soon

[**Learn How to Build A House**](https://www.eventbrite.com/e/learn-how-to-build-a-house-tickets-1407886890589?aff=ebdssbcitybrowse)

Saturday • 10:00 AM

John L. Scott Real Estate \| Yakima

Check ticket price on event

_Save this event: Learn How to Build A House__Share this event: Learn How to Build A House_

[![Bridging Generational Gaps - YAKIMA, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F876616729%2F2404763187013%2F1%2Foriginal.20241017-024545?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=50586210b2c4bb481e1592e9b78a239a)](https://www.eventbrite.com/e/bridging-generational-gaps-yakima-wa-tickets-1204179576529?aff=ebdssbcitybrowse)

[**Bridging Generational Gaps - YAKIMA, WA**](https://www.eventbrite.com/e/bridging-generational-gaps-yakima-wa-tickets-1204179576529?aff=ebdssbcitybrowse)

Monday • 5:00 PM + 9 more

Yakima

Check ticket price on event

_Save this event: Bridging Generational Gaps - YAKIMA, WA__Share this event: Bridging Generational Gaps - YAKIMA, WA_

[![Kids Cooking Workshop: Basics of Cooking primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1048607583%2F163869624577%2F1%2Foriginal.20250609-000729?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=08680161567eaab602cf6e56357b28ad)](https://www.eventbrite.com/e/kids-cooking-workshop-basics-of-cooking-tickets-1405275459729?aff=ebdssbcitybrowse)

Going fast

[**Kids Cooking Workshop: Basics of Cooking**](https://www.eventbrite.com/e/kids-cooking-workshop-basics-of-cooking-tickets-1405275459729?aff=ebdssbcitybrowse)

Thu, Jun 26 • 1:00 PM

Healthy Eats Classroom

Check ticket price on event

_Save this event: Kids Cooking Workshop: Basics of Cooking__Share this event: Kids Cooking Workshop: Basics of Cooking_

[![How to buy a house in 2025 primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1047171813%2F519615972615%2F1%2Foriginal.20250606-032902?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.516949152542&fp-y=0.0955414012739&s=30b4ee89b0eb90f5a3369a625560f574)](https://www.eventbrite.com/e/how-to-buy-a-house-in-2025-tickets-1400812380539?aff=ebdssbcitybrowse)

[**How to buy a house in 2025**](https://www.eventbrite.com/e/how-to-buy-a-house-in-2025-tickets-1400812380539?aff=ebdssbcitybrowse)

Sat, Jun 28 • 10:00 AM

Yakima Association of REALTORS

Check ticket price on event

_Save this event: How to buy a house in 2025__Share this event: How to buy a house in 2025_

[![Hell’s Belles – Rock - AC/DC Tribute Band @Hoops primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1044100743%2F544198379297%2F1%2Foriginal.20250602-185216?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.518939393939&fp-y=0.238402061856&s=901666465f610f4c61dff80272fc2766)](https://www.eventbrite.com/e/hells-belles-rock-acdc-tribute-band-hoops-tickets-1393096793009?aff=ebdssbcitybrowse)

[**Hell’s Belles – Rock - AC/DC Tribute Band @Hoops**](https://www.eventbrite.com/e/hells-belles-rock-acdc-tribute-band-hoops-tickets-1393096793009?aff=ebdssbcitybrowse)

Sat, Jul 19 • 7:00 PM

Hoops

Check ticket price on event

_Save this event: Hell’s Belles – Rock - AC/DC Tribute Band @Hoops__Share this event: Hell’s Belles – Rock - AC/DC Tribute Band @Hoops_

[![Foundations of Digital Photography (6-Week Course) primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1044837803%2F137493871735%2F1%2Foriginal.20250603-150941?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.486742424242&fp-y=0.507434944238&s=699a7ef0538356bcd8967179c290e48b)](https://www.eventbrite.com/e/foundations-of-digital-photography-6-week-course-tickets-1393174926709?aff=ebdssbcitybrowse)

[**Foundations of Digital Photography (6-Week Course)**](https://www.eventbrite.com/e/foundations-of-digital-photography-6-week-course-tickets-1393174926709?aff=ebdssbcitybrowse)

Tue, Jul 22 • 6:00 PM

26 N 1st St suite a

Check ticket price on event

_Save this event: Foundations of Digital Photography (6-Week Course)__Share this event: Foundations of Digital Photography (6-Week Course)_

[![United in Hope, Together We Rise: WSCADV 2025 Conference primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1031093433%2F40101533418%2F1%2Foriginal.20250514-202704?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.498106060606&fp-y=0.356343283582&s=6274ffc98afca05c09307e21ea511d2e)](https://www.eventbrite.com/e/united-in-hope-together-we-rise-wscadv-2025-conference-registration-1307303673479?aff=ebdssbcitybrowse)

[**United in Hope, Together We Rise: WSCADV 2025 Conference**](https://www.eventbrite.com/e/united-in-hope-together-we-rise-wscadv-2025-conference-registration-1307303673479?aff=ebdssbcitybrowse)

Yakima Convention Center

Check ticket price on event

_Save this event: United in Hope, Together We Rise: WSCADV 2025 Conference__Share this event: United in Hope, Together We Rise: WSCADV 2025 Conference_

[Explore more events](https://www.eventbrite.com/d/wa--yakima/all-events/)

## [Online Events](https://www.eventbrite.com/d/online/all-events/)

[Explore more events](https://www.eventbrite.com/d/online/all-events/)

[![Family history: tracing your Irish ancestors primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F946809113%2F1061130206503%2F1%2Foriginal.20250128-181559?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C347%2C5028%2C2514&s=cc03662005eb2a95b143a4af3f0ffdb3)](https://www.eventbrite.co.uk/e/family-history-tracing-your-irish-ancestors-tickets-1223529432469?aff=ebdssbcitybrowse)

Going fast

[**Family history: tracing your Irish ancestors**](https://www.eventbrite.co.uk/e/family-history-tracing-your-irish-ancestors-tickets-1223529432469?aff=ebdssbcitybrowse)

Tomorrow • 2:00 PM GMT+1

Check ticket price on event

_Save this event: Family history: tracing your Irish ancestors__Share this event: Family history: tracing your Irish ancestors_

[![Voices of Plants for a Better World primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F935724163%2F620392206543%2F1%2Foriginal.20250114-202450?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=5a7346e63eb1915b6cda1d4f63a67067)](https://www.eventbrite.com/e/voices-of-plants-for-a-better-world-tickets-1200380663879?aff=ebdssbcitybrowse)

Going fast

[**Voices of Plants for a Better World**](https://www.eventbrite.com/e/voices-of-plants-for-a-better-world-tickets-1200380663879?aff=ebdssbcitybrowse)

Tomorrow • 10:00 AM CDT

Check ticket price on event

_Save this event: Voices of Plants for a Better World__Share this event: Voices of Plants for a Better World_

[![Career Fair: Exclusive Tech Hiring Event-New Tickets Available primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F682597209%2F197361445633%2F1%2Foriginal.20240125-160053?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C940%2C470&s=1790a7734766e877ae40e832f440984d)](https://www.eventbrite.com/e/career-fair-exclusive-tech-hiring-event-new-tickets-available-tickets-63049080497?aff=ebdssbcitybrowse)

[**Career Fair: Exclusive Tech Hiring Event-New Tickets Available**](https://www.eventbrite.com/e/career-fair-exclusive-tech-hiring-event-new-tickets-available-tickets-63049080497?aff=ebdssbcitybrowse)

Fri, Jun 27 • 9:00 AM PDT

Check ticket price on event

_Save this event: Career Fair: Exclusive Tech Hiring Event-New Tickets Available__Share this event: Career Fair: Exclusive Tech Hiring Event-New Tickets Available_

[![Newark Career Fair primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F694567149%2F316131771624%2F1%2Foriginal.20240211-004545?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C12%2C696%2C348&s=58a6bacc96d9f5d287230d2605271651)](https://www.eventbrite.com/e/newark-career-fair-tickets-833923195727?aff=ebdssbcitybrowse)

Almost full

[**Newark Career Fair**](https://www.eventbrite.com/e/newark-career-fair-tickets-833923195727?aff=ebdssbcitybrowse)

Mon, Jun 30 • 9:30 AM EDT

Check ticket price on event

_Save this event: Newark Career Fair__Share this event: Newark Career Fair_

[![SLBI Dues 2025-2026 primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F941313663%2F300055468767%2F1%2Foriginal.20250121-205252?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=c99d9387959579922ab3edf01725a5cb)](https://www.eventbrite.com/e/slbi-dues-2025-2026-tickets-1217089189529?aff=ebdssbcitybrowse)

Almost full

[**SLBI Dues 2025-2026**](https://www.eventbrite.com/e/slbi-dues-2025-2026-tickets-1217089189529?aff=ebdssbcitybrowse)

Mon, Jun 30 • 10:00 AM PDT

Check ticket price on event

_Save this event: SLBI Dues 2025-2026__Share this event: SLBI Dues 2025-2026_

[![Working with Angry Teens primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F998996213%2F540777674815%2F1%2Foriginal.20250402-160128?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.00502901353965&fp-y=0.00468474565926&s=64b596318d6e3c1e8a702be269417f18)](https://www.eventbrite.com/e/working-with-angry-teens-tickets-1219655465329?aff=ebdssbcitybrowse)

[**Working with Angry Teens**](https://www.eventbrite.com/e/working-with-angry-teens-tickets-1219655465329?aff=ebdssbcitybrowse)

Mon, Jun 30 • 1:00 PM EDT

Check ticket price on event

_Save this event: Working with Angry Teens__Share this event: Working with Angry Teens_

[![Single  and Intentional (Ages 25+ preferred)** Virtual Event** primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F708001649%2F1999088473903%2F1%2Foriginal.20240229-050947?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C1148%2C2912%2C1456&s=583581000d4b553b8354c355bdb7f322)](https://www.eventbrite.com/e/single-and-intentional-ages-25-preferred-virtual-event-tickets-1045297481907?aff=ebdssbcitybrowse)

Almost full

[**Single and Intentional (Ages 25+ preferred)\*\* Virtual Event\*\***](https://www.eventbrite.com/e/single-and-intentional-ages-25-preferred-virtual-event-tickets-1045297481907?aff=ebdssbcitybrowse)

Check ticket price on event

_Save this event: Single and Intentional (Ages 25+ preferred)\*\* Virtual Event\*\*__Share this event: Single and Intentional (Ages 25+ preferred)\*\* Virtual Event\*\*_

[![No Cost On-Line Coursera Certification Courses For Military and Spouse primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F631748609%2F122310519079%2F1%2Foriginal.20231031-040429?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=9b7a42e3580929f655116c091d698c90)](https://www.eventbrite.com/e/no-cost-on-line-coursera-certification-courses-for-military-and-spouse-tickets-165655358637?aff=ebdssbcitybrowse)

Almost full

[**No Cost On-Line Coursera Certification Courses For Military and Spouse**](https://www.eventbrite.com/e/no-cost-on-line-coursera-certification-courses-for-military-and-spouse-tickets-165655358637?aff=ebdssbcitybrowse)

Check ticket price on event

_Save this event: No Cost On-Line Coursera Certification Courses For Military and Spouse__Share this event: No Cost On-Line Coursera Certification Courses For Military and Spouse_

[![Family history: tracing your Irish ancestors primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F946809113%2F1061130206503%2F1%2Foriginal.20250128-181559?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C347%2C5028%2C2514&s=cc03662005eb2a95b143a4af3f0ffdb3)](https://www.eventbrite.co.uk/e/family-history-tracing-your-irish-ancestors-tickets-1223529432469?aff=ebdssbcitybrowse)

Going fast

[**Family history: tracing your Irish ancestors**](https://www.eventbrite.co.uk/e/family-history-tracing-your-irish-ancestors-tickets-1223529432469?aff=ebdssbcitybrowse)

Tomorrow • 2:00 PM GMT+1

Check ticket price on event

_Save this event: Family history: tracing your Irish ancestors__Share this event: Family history: tracing your Irish ancestors_

[![Voices of Plants for a Better World primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F935724163%2F620392206543%2F1%2Foriginal.20250114-202450?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=5a7346e63eb1915b6cda1d4f63a67067)](https://www.eventbrite.com/e/voices-of-plants-for-a-better-world-tickets-1200380663879?aff=ebdssbcitybrowse)

Going fast

[**Voices of Plants for a Better World**](https://www.eventbrite.com/e/voices-of-plants-for-a-better-world-tickets-1200380663879?aff=ebdssbcitybrowse)

Tomorrow • 10:00 AM CDT

Check ticket price on event

_Save this event: Voices of Plants for a Better World__Share this event: Voices of Plants for a Better World_

[![Career Fair: Exclusive Tech Hiring Event-New Tickets Available primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F682597209%2F197361445633%2F1%2Foriginal.20240125-160053?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C940%2C470&s=1790a7734766e877ae40e832f440984d)](https://www.eventbrite.com/e/career-fair-exclusive-tech-hiring-event-new-tickets-available-tickets-63049080497?aff=ebdssbcitybrowse)

[**Career Fair: Exclusive Tech Hiring Event-New Tickets Available**](https://www.eventbrite.com/e/career-fair-exclusive-tech-hiring-event-new-tickets-available-tickets-63049080497?aff=ebdssbcitybrowse)

Fri, Jun 27 • 9:00 AM PDT

Check ticket price on event

_Save this event: Career Fair: Exclusive Tech Hiring Event-New Tickets Available__Share this event: Career Fair: Exclusive Tech Hiring Event-New Tickets Available_

[![Newark Career Fair primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F694567149%2F316131771624%2F1%2Foriginal.20240211-004545?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C12%2C696%2C348&s=58a6bacc96d9f5d287230d2605271651)](https://www.eventbrite.com/e/newark-career-fair-tickets-833923195727?aff=ebdssbcitybrowse)

Almost full

[**Newark Career Fair**](https://www.eventbrite.com/e/newark-career-fair-tickets-833923195727?aff=ebdssbcitybrowse)

Mon, Jun 30 • 9:30 AM EDT

Check ticket price on event

_Save this event: Newark Career Fair__Share this event: Newark Career Fair_

[![SLBI Dues 2025-2026 primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F941313663%2F300055468767%2F1%2Foriginal.20250121-205252?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=c99d9387959579922ab3edf01725a5cb)](https://www.eventbrite.com/e/slbi-dues-2025-2026-tickets-1217089189529?aff=ebdssbcitybrowse)

Almost full

[**SLBI Dues 2025-2026**](https://www.eventbrite.com/e/slbi-dues-2025-2026-tickets-1217089189529?aff=ebdssbcitybrowse)

Mon, Jun 30 • 10:00 AM PDT

Check ticket price on event

_Save this event: SLBI Dues 2025-2026__Share this event: SLBI Dues 2025-2026_

[![Working with Angry Teens primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F998996213%2F540777674815%2F1%2Foriginal.20250402-160128?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.00502901353965&fp-y=0.00468474565926&s=64b596318d6e3c1e8a702be269417f18)](https://www.eventbrite.com/e/working-with-angry-teens-tickets-1219655465329?aff=ebdssbcitybrowse)

[**Working with Angry Teens**](https://www.eventbrite.com/e/working-with-angry-teens-tickets-1219655465329?aff=ebdssbcitybrowse)

Mon, Jun 30 • 1:00 PM EDT

Check ticket price on event

_Save this event: Working with Angry Teens__Share this event: Working with Angry Teens_

[![Single  and Intentional (Ages 25+ preferred)** Virtual Event** primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F708001649%2F1999088473903%2F1%2Foriginal.20240229-050947?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C1148%2C2912%2C1456&s=583581000d4b553b8354c355bdb7f322)](https://www.eventbrite.com/e/single-and-intentional-ages-25-preferred-virtual-event-tickets-1045297481907?aff=ebdssbcitybrowse)

Almost full

[**Single and Intentional (Ages 25+ preferred)\*\* Virtual Event\*\***](https://www.eventbrite.com/e/single-and-intentional-ages-25-preferred-virtual-event-tickets-1045297481907?aff=ebdssbcitybrowse)

Check ticket price on event

_Save this event: Single and Intentional (Ages 25+ preferred)\*\* Virtual Event\*\*__Share this event: Single and Intentional (Ages 25+ preferred)\*\* Virtual Event\*\*_

[![No Cost On-Line Coursera Certification Courses For Military and Spouse primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F631748609%2F122310519079%2F1%2Foriginal.20231031-040429?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=9b7a42e3580929f655116c091d698c90)](https://www.eventbrite.com/e/no-cost-on-line-coursera-certification-courses-for-military-and-spouse-tickets-165655358637?aff=ebdssbcitybrowse)

Almost full

[**No Cost On-Line Coursera Certification Courses For Military and Spouse**](https://www.eventbrite.com/e/no-cost-on-line-coursera-certification-courses-for-military-and-spouse-tickets-165655358637?aff=ebdssbcitybrowse)

Check ticket price on event

_Save this event: No Cost On-Line Coursera Certification Courses For Military and Spouse__Share this event: No Cost On-Line Coursera Certification Courses For Military and Spouse_

[Explore more events](https://www.eventbrite.com/d/online/all-events/)

## [This Weekend](https://www.eventbrite.com/d/wa--yakima/events--this-weekend/)

[Explore more events](https://www.eventbrite.com/d/wa--yakima/events--this-weekend/)

[![She’s Crafty with Christin primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1053063063%2F211389770296%2F1%2Foriginal.20250614-144114?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.00380350194553&fp-y=0.00860894941634&s=ecdcd9975aa23f1a778707f043ffc124)](https://www.eventbrite.com/e/shes-crafty-with-christin-tickets-1361235745759?aff=ebdssbcitybrowse)

Sales end soon

[**She’s Crafty with Christin**](https://www.eventbrite.com/e/shes-crafty-with-christin-tickets-1361235745759?aff=ebdssbcitybrowse)

Tomorrow • 7:00 PM

Rooted Yakima Valley

Check ticket price on event

_Save this event: She’s Crafty with Christin__Share this event: She’s Crafty with Christin_

[![Prime Rib Dinner for Two Special primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F996437833%2F562053872915%2F1%2Foriginal.20250331-051841?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=4bc6dfdf3ec52c44f3e9966a4a055e42)](https://www.eventbrite.com/e/prime-rib-dinner-for-two-special-tickets-1304172116909?aff=ebdssbcitybrowse)

[**Prime Rib Dinner for Two Special**](https://www.eventbrite.com/e/prime-rib-dinner-for-two-special-tickets-1304172116909?aff=ebdssbcitybrowse)

Tomorrow • 5:00 PM

Casino Caribbean Yakima

Check ticket price on event

_Save this event: Prime Rib Dinner for Two Special__Share this event: Prime Rib Dinner for Two Special_

[![Tea Tasting with Molly primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1044949453%2F2751236273451%2F1%2Foriginal.20250603-165312?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.471590909091&fp-y=0.684824902724&s=07e14be9726a4c0e84700198ead9b2a9)](https://www.eventbrite.com/e/tea-tasting-with-molly-tickets-1395027477739?aff=ebdssbcitybrowse)

[**Tea Tasting with Molly**](https://www.eventbrite.com/e/tea-tasting-with-molly-tickets-1395027477739?aff=ebdssbcitybrowse)

Saturday • 10:00 AM + 1 more

3508 Summitview Ave

Check ticket price on event

_Save this event: Tea Tasting with Molly__Share this event: Tea Tasting with Molly_

[![Yakima, WA: Murder Mystery Detective Experience primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F396581179%2F1178052885873%2F1%2Foriginal.20221119-171302?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=42d887b0ebfed8af07e521b92098f2d8)](https://www.eventbrite.ca/e/yakima-wa-murder-mystery-detective-experience-tickets-797149143547?aff=ebdssbcitybrowse)

[**Yakima, WA: Murder Mystery Detective Experience**](https://www.eventbrite.ca/e/yakima-wa-murder-mystery-detective-experience-tickets-797149143547?aff=ebdssbcitybrowse)

Saturday • 10:00 AM + 1 more

Yakima\| Drive or Walk

Check ticket price on event

_Save this event: Yakima, WA: Murder Mystery Detective Experience__Share this event: Yakima, WA: Murder Mystery Detective Experience_

[![Learn How to Build A House primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1050286333%2F2679151205591%2F1%2Foriginal.20250610-224619?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=066bf671ee341eba38bd8e4dbaf10ba7)](https://www.eventbrite.com/e/learn-how-to-build-a-house-tickets-1407886890589?aff=ebdssbcitybrowse)

Sales end soon

[**Learn How to Build A House**](https://www.eventbrite.com/e/learn-how-to-build-a-house-tickets-1407886890589?aff=ebdssbcitybrowse)

Saturday • 10:00 AM

John L. Scott Real Estate \| Yakima

Check ticket price on event

_Save this event: Learn How to Build A House__Share this event: Learn How to Build A House_

[![Yakima Area - Pop Up Picnic Park Date for Couples! (Self-Guided)! primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F440661549%2F1380302521983%2F1%2Foriginal.20230204-063108?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C7%2C612%2C306&s=6811ceb13f2be145f7c6b2d0cf503759)](https://www.eventbrite.com/e/yakima-area-pop-up-picnic-park-date-for-couples-self-guided-tickets-838689562057?aff=ebdssbcitybrowse)

[**Yakima Area - Pop Up Picnic Park Date for Couples! (Self-Guided)!**](https://www.eventbrite.com/e/yakima-area-pop-up-picnic-park-date-for-couples-self-guided-tickets-838689562057?aff=ebdssbcitybrowse)

Saturday • 1:00 PM + 1 more

Miller Park - Recommended Park Venue or another park choice (YOU MUST USE PDF TICKETS EMAILED FOR EVENT- NO MOBILE APP OR QR CODES ACCEPTED)

Check ticket price on event

_Save this event: Yakima Area - Pop Up Picnic Park Date for Couples! (Self-Guided)!__Share this event: Yakima Area - Pop Up Picnic Park Date for Couples! (Self-Guided)!_

[![Self-Care City Scavenger Hunt: Based on Hot Habits Series -Yakima Area primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F844472279%2F1395832153743%2F1%2Foriginal.20240907-195113?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.005&fp-y=0.005&s=da13dd3daaccfa6bfa7611f197ac10a8)](https://www.eventbrite.com/e/self-care-city-scavenger-hunt-based-on-hot-habits-series-yakima-area-tickets-1056761635499?aff=ebdssbcitybrowse)

[**Self-Care City Scavenger Hunt: Based on Hot Habits Series -Yakima Area**](https://www.eventbrite.com/e/self-care-city-scavenger-hunt-based-on-hot-habits-series-yakima-area-tickets-1056761635499?aff=ebdssbcitybrowse)

Saturday • 1:00 PM + 1 more

\*Recommended scavenger starting point or other city spot of your choice! (YOU MUST USE PDF TICKETS EMAILED FOR EVENT- NO MOBILE APP OR QR CODES ACCEPTED)

Check ticket price on event

_Save this event: Self-Care City Scavenger Hunt: Based on Hot Habits Series -Yakima Area__Share this event: Self-Care City Scavenger Hunt: Based on Hot Habits Series -Yakima Area_

[![Master Public Speaking & captivate any room with confidence — Online Event primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F694599259%2F1574767101513%2F1%2Foriginal.20240211-025856?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C60%2C1920%2C960&s=87e7ff263efd10ff9a37ef13cade068f)](https://www.eventbrite.com/e/master-public-speaking-captivate-any-room-with-confidence-online-event-tickets-1085050889419?aff=ebdssbcitybrowse)

[**Master Public Speaking & captivate any room with confidence — Online Event**](https://www.eventbrite.com/e/master-public-speaking-captivate-any-room-with-confidence-online-event-tickets-1085050889419?aff=ebdssbcitybrowse)

Saturday • 3:00 PM

Yakima

Check ticket price on event

_Save this event: Master Public Speaking & captivate any room with confidence — Online Event__Share this event: Master Public Speaking & captivate any room with confidence — Online Event_

[![She’s Crafty with Christin primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1053063063%2F211389770296%2F1%2Foriginal.20250614-144114?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.00380350194553&fp-y=0.00860894941634&s=ecdcd9975aa23f1a778707f043ffc124)](https://www.eventbrite.com/e/shes-crafty-with-christin-tickets-1361235745759?aff=ebdssbcitybrowse)

Sales end soon

[**She’s Crafty with Christin**](https://www.eventbrite.com/e/shes-crafty-with-christin-tickets-1361235745759?aff=ebdssbcitybrowse)

Tomorrow • 7:00 PM

Rooted Yakima Valley

Check ticket price on event

_Save this event: She’s Crafty with Christin__Share this event: She’s Crafty with Christin_

[![Prime Rib Dinner for Two Special primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F996437833%2F562053872915%2F1%2Foriginal.20250331-051841?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=4bc6dfdf3ec52c44f3e9966a4a055e42)](https://www.eventbrite.com/e/prime-rib-dinner-for-two-special-tickets-1304172116909?aff=ebdssbcitybrowse)

[**Prime Rib Dinner for Two Special**](https://www.eventbrite.com/e/prime-rib-dinner-for-two-special-tickets-1304172116909?aff=ebdssbcitybrowse)

Tomorrow • 5:00 PM

Casino Caribbean Yakima

Check ticket price on event

_Save this event: Prime Rib Dinner for Two Special__Share this event: Prime Rib Dinner for Two Special_

[![Tea Tasting with Molly primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1044949453%2F2751236273451%2F1%2Foriginal.20250603-165312?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.471590909091&fp-y=0.684824902724&s=07e14be9726a4c0e84700198ead9b2a9)](https://www.eventbrite.com/e/tea-tasting-with-molly-tickets-1395027477739?aff=ebdssbcitybrowse)

[**Tea Tasting with Molly**](https://www.eventbrite.com/e/tea-tasting-with-molly-tickets-1395027477739?aff=ebdssbcitybrowse)

Saturday • 10:00 AM + 1 more

3508 Summitview Ave

Check ticket price on event

_Save this event: Tea Tasting with Molly__Share this event: Tea Tasting with Molly_

[![Yakima, WA: Murder Mystery Detective Experience primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F396581179%2F1178052885873%2F1%2Foriginal.20221119-171302?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=42d887b0ebfed8af07e521b92098f2d8)](https://www.eventbrite.ca/e/yakima-wa-murder-mystery-detective-experience-tickets-797149143547?aff=ebdssbcitybrowse)

[**Yakima, WA: Murder Mystery Detective Experience**](https://www.eventbrite.ca/e/yakima-wa-murder-mystery-detective-experience-tickets-797149143547?aff=ebdssbcitybrowse)

Saturday • 10:00 AM + 1 more

Yakima\| Drive or Walk

Check ticket price on event

_Save this event: Yakima, WA: Murder Mystery Detective Experience__Share this event: Yakima, WA: Murder Mystery Detective Experience_

[![Learn How to Build A House primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1050286333%2F2679151205591%2F1%2Foriginal.20250610-224619?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.5&fp-y=0.5&s=066bf671ee341eba38bd8e4dbaf10ba7)](https://www.eventbrite.com/e/learn-how-to-build-a-house-tickets-1407886890589?aff=ebdssbcitybrowse)

Sales end soon

[**Learn How to Build A House**](https://www.eventbrite.com/e/learn-how-to-build-a-house-tickets-1407886890589?aff=ebdssbcitybrowse)

Saturday • 10:00 AM

John L. Scott Real Estate \| Yakima

Check ticket price on event

_Save this event: Learn How to Build A House__Share this event: Learn How to Build A House_

[![Yakima Area - Pop Up Picnic Park Date for Couples! (Self-Guided)! primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F440661549%2F1380302521983%2F1%2Foriginal.20230204-063108?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C7%2C612%2C306&s=6811ceb13f2be145f7c6b2d0cf503759)](https://www.eventbrite.com/e/yakima-area-pop-up-picnic-park-date-for-couples-self-guided-tickets-838689562057?aff=ebdssbcitybrowse)

[**Yakima Area - Pop Up Picnic Park Date for Couples! (Self-Guided)!**](https://www.eventbrite.com/e/yakima-area-pop-up-picnic-park-date-for-couples-self-guided-tickets-838689562057?aff=ebdssbcitybrowse)

Saturday • 1:00 PM + 1 more

Miller Park - Recommended Park Venue or another park choice (YOU MUST USE PDF TICKETS EMAILED FOR EVENT- NO MOBILE APP OR QR CODES ACCEPTED)

Check ticket price on event

_Save this event: Yakima Area - Pop Up Picnic Park Date for Couples! (Self-Guided)!__Share this event: Yakima Area - Pop Up Picnic Park Date for Couples! (Self-Guided)!_

[![Self-Care City Scavenger Hunt: Based on Hot Habits Series -Yakima Area primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F844472279%2F1395832153743%2F1%2Foriginal.20240907-195113?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.005&fp-y=0.005&s=da13dd3daaccfa6bfa7611f197ac10a8)](https://www.eventbrite.com/e/self-care-city-scavenger-hunt-based-on-hot-habits-series-yakima-area-tickets-1056761635499?aff=ebdssbcitybrowse)

[**Self-Care City Scavenger Hunt: Based on Hot Habits Series -Yakima Area**](https://www.eventbrite.com/e/self-care-city-scavenger-hunt-based-on-hot-habits-series-yakima-area-tickets-1056761635499?aff=ebdssbcitybrowse)

Saturday • 1:00 PM + 1 more

\*Recommended scavenger starting point or other city spot of your choice! (YOU MUST USE PDF TICKETS EMAILED FOR EVENT- NO MOBILE APP OR QR CODES ACCEPTED)

Check ticket price on event

_Save this event: Self-Care City Scavenger Hunt: Based on Hot Habits Series -Yakima Area__Share this event: Self-Care City Scavenger Hunt: Based on Hot Habits Series -Yakima Area_

[![Master Public Speaking & captivate any room with confidence — Online Event primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F694599259%2F1574767101513%2F1%2Foriginal.20240211-025856?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C60%2C1920%2C960&s=87e7ff263efd10ff9a37ef13cade068f)](https://www.eventbrite.com/e/master-public-speaking-captivate-any-room-with-confidence-online-event-tickets-1085050889419?aff=ebdssbcitybrowse)

[**Master Public Speaking & captivate any room with confidence — Online Event**](https://www.eventbrite.com/e/master-public-speaking-captivate-any-room-with-confidence-online-event-tickets-1085050889419?aff=ebdssbcitybrowse)

Saturday • 3:00 PM

Yakima

Check ticket price on event

_Save this event: Master Public Speaking & captivate any room with confidence — Online Event__Share this event: Master Public Speaking & captivate any room with confidence — Online Event_

[Explore more events](https://www.eventbrite.com/d/wa--yakima/events--this-weekend/)

## Business & Professional events

[![Master Public Speaking & captivate any room with confidence — Online Event primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F694599259%2F1574767101513%2F1%2Foriginal.20240211-025856?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C60%2C1920%2C960&s=87e7ff263efd10ff9a37ef13cade068f)](https://www.eventbrite.com/e/master-public-speaking-captivate-any-room-with-confidence-online-event-tickets-1085050889419?aff=ebdssbcitybrowse)

[**Master Public Speaking & captivate any room with confidence — Online Event**](https://www.eventbrite.com/e/master-public-speaking-captivate-any-room-with-confidence-online-event-tickets-1085050889419?aff=ebdssbcitybrowse)

Tomorrow • 3:00 PM + 207 more

Yakima

Check ticket price on event

_Save this event: Master Public Speaking & captivate any room with confidence — Online Event__Share this event: Master Public Speaking & captivate any room with confidence — Online Event_

[![Pursuing Peace & Purpose for Empaths & Highly Sensitives - Yakima primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F663984129%2F1062964567773%2F1%2Foriginal.20231228-023807?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=326b72e1442d613520c8115e077de891)](https://www.eventbrite.com/e/pursuing-peace-purpose-for-empaths-highly-sensitives-yakima-tickets-1312062808179?aff=ebdssbcitybrowse)

[**Pursuing Peace & Purpose for Empaths & Highly Sensitives - Yakima**](https://www.eventbrite.com/e/pursuing-peace-purpose-for-empaths-highly-sensitives-yakima-tickets-1312062808179?aff=ebdssbcitybrowse)

Monday • 6:00 PM + 18 more

Virtual via Zoom

Check ticket price on event

_Save this event: Pursuing Peace & Purpose for Empaths & Highly Sensitives - Yakima__Share this event: Pursuing Peace & Purpose for Empaths & Highly Sensitives - Yakima_

[![CAPM Certification 4 Days Classroom Training in Yakima, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F461514809%2F302388572969%2F1%2Foriginal.20220503-002407?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=30205ddffbe4712764a5be500df0af9e)](https://www.eventbrite.com/e/capm-certification-4-days-classroom-training-in-yakima-wa-tickets-574036276957?aff=ebdssbcitybrowse)

[**CAPM Certification 4 Days Classroom Training in Yakima, WA**](https://www.eventbrite.com/e/capm-certification-4-days-classroom-training-in-yakima-wa-tickets-574036276957?aff=ebdssbcitybrowse)

Tuesday • 9:00 AM

Yakima, WA

Check ticket price on event

_Save this event: CAPM Certification 4 Days Classroom Training in Yakima, WA__Share this event: CAPM Certification 4 Days Classroom Training in Yakima, WA_

[![PMI-ACP 3 Days Classroom Certification Training in Yakima, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F556782889%2F287307298896%2F1%2Foriginal.20211019-141603?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=adfc2baf1a48bab79f3115b7ed7d2d1d)](https://www.eventbrite.com/e/pmi-acp-3-days-classroom-certification-training-in-yakima-wa-tickets-679641936327?aff=ebdssbcitybrowse)

[**PMI-ACP 3 Days Classroom Certification Training in Yakima, WA**](https://www.eventbrite.com/e/pmi-acp-3-days-classroom-certification-training-in-yakima-wa-tickets-679641936327?aff=ebdssbcitybrowse)

Wednesday • 9:00 AM

Yakima, WA

Check ticket price on event

_Save this event: PMI-ACP 3 Days Classroom Certification Training in Yakima, WA__Share this event: PMI-ACP 3 Days Classroom Certification Training in Yakima, WA_

[![Data Analytics Certification Training in Yakima, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F997631323%2F1072417588943%2F1%2Foriginal.20250401-092737?w=403&auto=format%2Ccompress&q=75&sharp=10&s=5598ace57dd99956f57fa4348a77dab4)](https://www.eventbrite.com/e/data-analytics-certification-training-in-yakima-wa-tickets-1312252174579?aff=ebdssbcitybrowse)

[**Data Analytics Certification Training in Yakima, WA**](https://www.eventbrite.com/e/data-analytics-certification-training-in-yakima-wa-tickets-1312252174579?aff=ebdssbcitybrowse)

Wednesday • 9:00 AM + 9 more

Yakima, WA

Check ticket price on event

_Save this event: Data Analytics Certification Training in Yakima, WA__Share this event: Data Analytics Certification Training in Yakima, WA_

[![Project Management Techniques Certification Training in Yakima, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F991667243%2F2032835883643%2F1%2Foriginal.20250324-223023?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=5e-09&fp-y=5e-09&s=8e97d7e2c379f6664e7256cf15c7fb2a)](https://www.eventbrite.com/e/project-management-techniques-certification-training-in-yakima-wa-tickets-1341909851489?aff=ebdssbcitybrowse)

[**Project Management Techniques Certification Training in Yakima, WA**](https://www.eventbrite.com/e/project-management-techniques-certification-training-in-yakima-wa-tickets-1341909851489?aff=ebdssbcitybrowse)

Fri, Jun 27 • 9:00 AM + 23 more

Regus

Check ticket price on event

_Save this event: Project Management Techniques Certification Training in Yakima, WA__Share this event: Project Management Techniques Certification Training in Yakima, WA_

[![Conflict Management Certification Bootcamp Course in West Valley, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F981344783%2F2032768092403%2F1%2Foriginal.20250311-230217?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=5e-15&fp-y=5e-15&s=410b0a75bcb9311b3728c9e4e17080dc)](https://www.eventbrite.com/e/conflict-management-certification-bootcamp-course-in-west-valley-wa-tickets-1387480996009?aff=ebdssbcitybrowse)

[**Conflict Management Certification Bootcamp Course in West Valley, WA**](https://www.eventbrite.com/e/conflict-management-certification-bootcamp-course-in-west-valley-wa-tickets-1387480996009?aff=ebdssbcitybrowse)

Fri, Jun 27 • 9:00 AM + 23 more

Regus - The venue will be close to your place. It can be conducted near your zip code

Check ticket price on event

_Save this event: Conflict Management Certification Bootcamp Course in West Valley, WA__Share this event: Conflict Management Certification Bootcamp Course in West Valley, WA_

[![How to buy a house in 2025 primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1047171813%2F519615972615%2F1%2Foriginal.20250606-032902?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.516949152542&fp-y=0.0955414012739&s=30b4ee89b0eb90f5a3369a625560f574)](https://www.eventbrite.com/e/how-to-buy-a-house-in-2025-tickets-1400812380539?aff=ebdssbcitybrowse)

[**How to buy a house in 2025**](https://www.eventbrite.com/e/how-to-buy-a-house-in-2025-tickets-1400812380539?aff=ebdssbcitybrowse)

Sat, Jun 28 • 10:00 AM

Yakima Association of REALTORS

Check ticket price on event

_Save this event: How to buy a house in 2025__Share this event: How to buy a house in 2025_

[![Master Public Speaking & captivate any room with confidence — Online Event primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F694599259%2F1574767101513%2F1%2Foriginal.20240211-025856?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C60%2C1920%2C960&s=87e7ff263efd10ff9a37ef13cade068f)](https://www.eventbrite.com/e/master-public-speaking-captivate-any-room-with-confidence-online-event-tickets-1085050889419?aff=ebdssbcitybrowse)

[**Master Public Speaking & captivate any room with confidence — Online Event**](https://www.eventbrite.com/e/master-public-speaking-captivate-any-room-with-confidence-online-event-tickets-1085050889419?aff=ebdssbcitybrowse)

Tomorrow • 3:00 PM + 207 more

Yakima

Check ticket price on event

_Save this event: Master Public Speaking & captivate any room with confidence — Online Event__Share this event: Master Public Speaking & captivate any room with confidence — Online Event_

[![Pursuing Peace & Purpose for Empaths & Highly Sensitives - Yakima primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F663984129%2F1062964567773%2F1%2Foriginal.20231228-023807?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=326b72e1442d613520c8115e077de891)](https://www.eventbrite.com/e/pursuing-peace-purpose-for-empaths-highly-sensitives-yakima-tickets-1312062808179?aff=ebdssbcitybrowse)

[**Pursuing Peace & Purpose for Empaths & Highly Sensitives - Yakima**](https://www.eventbrite.com/e/pursuing-peace-purpose-for-empaths-highly-sensitives-yakima-tickets-1312062808179?aff=ebdssbcitybrowse)

Monday • 6:00 PM + 18 more

Virtual via Zoom

Check ticket price on event

_Save this event: Pursuing Peace & Purpose for Empaths & Highly Sensitives - Yakima__Share this event: Pursuing Peace & Purpose for Empaths & Highly Sensitives - Yakima_

[![CAPM Certification 4 Days Classroom Training in Yakima, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F461514809%2F302388572969%2F1%2Foriginal.20220503-002407?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=30205ddffbe4712764a5be500df0af9e)](https://www.eventbrite.com/e/capm-certification-4-days-classroom-training-in-yakima-wa-tickets-574036276957?aff=ebdssbcitybrowse)

[**CAPM Certification 4 Days Classroom Training in Yakima, WA**](https://www.eventbrite.com/e/capm-certification-4-days-classroom-training-in-yakima-wa-tickets-574036276957?aff=ebdssbcitybrowse)

Tuesday • 9:00 AM

Yakima, WA

Check ticket price on event

_Save this event: CAPM Certification 4 Days Classroom Training in Yakima, WA__Share this event: CAPM Certification 4 Days Classroom Training in Yakima, WA_

[![PMI-ACP 3 Days Classroom Certification Training in Yakima, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F556782889%2F287307298896%2F1%2Foriginal.20211019-141603?w=512&auto=format%2Ccompress&q=75&sharp=10&rect=0%2C0%2C2160%2C1080&s=adfc2baf1a48bab79f3115b7ed7d2d1d)](https://www.eventbrite.com/e/pmi-acp-3-days-classroom-certification-training-in-yakima-wa-tickets-679641936327?aff=ebdssbcitybrowse)

[**PMI-ACP 3 Days Classroom Certification Training in Yakima, WA**](https://www.eventbrite.com/e/pmi-acp-3-days-classroom-certification-training-in-yakima-wa-tickets-679641936327?aff=ebdssbcitybrowse)

Wednesday • 9:00 AM

Yakima, WA

Check ticket price on event

_Save this event: PMI-ACP 3 Days Classroom Certification Training in Yakima, WA__Share this event: PMI-ACP 3 Days Classroom Certification Training in Yakima, WA_

[![Data Analytics Certification Training in Yakima, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F997631323%2F1072417588943%2F1%2Foriginal.20250401-092737?w=403&auto=format%2Ccompress&q=75&sharp=10&s=5598ace57dd99956f57fa4348a77dab4)](https://www.eventbrite.com/e/data-analytics-certification-training-in-yakima-wa-tickets-1312252174579?aff=ebdssbcitybrowse)

[**Data Analytics Certification Training in Yakima, WA**](https://www.eventbrite.com/e/data-analytics-certification-training-in-yakima-wa-tickets-1312252174579?aff=ebdssbcitybrowse)

Wednesday • 9:00 AM + 9 more

Yakima, WA

Check ticket price on event

_Save this event: Data Analytics Certification Training in Yakima, WA__Share this event: Data Analytics Certification Training in Yakima, WA_

[![Project Management Techniques Certification Training in Yakima, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F991667243%2F2032835883643%2F1%2Foriginal.20250324-223023?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=5e-09&fp-y=5e-09&s=8e97d7e2c379f6664e7256cf15c7fb2a)](https://www.eventbrite.com/e/project-management-techniques-certification-training-in-yakima-wa-tickets-1341909851489?aff=ebdssbcitybrowse)

[**Project Management Techniques Certification Training in Yakima, WA**](https://www.eventbrite.com/e/project-management-techniques-certification-training-in-yakima-wa-tickets-1341909851489?aff=ebdssbcitybrowse)

Fri, Jun 27 • 9:00 AM + 23 more

Regus

Check ticket price on event

_Save this event: Project Management Techniques Certification Training in Yakima, WA__Share this event: Project Management Techniques Certification Training in Yakima, WA_

[![Conflict Management Certification Bootcamp Course in West Valley, WA primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F981344783%2F2032768092403%2F1%2Foriginal.20250311-230217?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=5e-15&fp-y=5e-15&s=410b0a75bcb9311b3728c9e4e17080dc)](https://www.eventbrite.com/e/conflict-management-certification-bootcamp-course-in-west-valley-wa-tickets-1387480996009?aff=ebdssbcitybrowse)

[**Conflict Management Certification Bootcamp Course in West Valley, WA**](https://www.eventbrite.com/e/conflict-management-certification-bootcamp-course-in-west-valley-wa-tickets-1387480996009?aff=ebdssbcitybrowse)

Fri, Jun 27 • 9:00 AM + 23 more

Regus - The venue will be close to your place. It can be conducted near your zip code

Check ticket price on event

_Save this event: Conflict Management Certification Bootcamp Course in West Valley, WA__Share this event: Conflict Management Certification Bootcamp Course in West Valley, WA_

[![How to buy a house in 2025 primary image](https://img.evbuc.com/https%3A%2F%2Fcdn.evbuc.com%2Fimages%2F1047171813%2F519615972615%2F1%2Foriginal.20250606-032902?crop=focalpoint&fit=crop&w=512&auto=format%2Ccompress&q=75&sharp=10&fp-x=0.516949152542&fp-y=0.0955414012739&s=30b4ee89b0eb90f5a3369a625560f574)](https://www.eventbrite.com/e/how-to-buy-a-house-in-2025-tickets-1400812380539?aff=ebdssbcitybrowse)

[**How to buy a house in 2025**](https://www.eventbrite.com/e/how-to-buy-a-house-in-2025-tickets-1400812380539?aff=ebdssbcitybrowse)

Sat, Jun 28 • 10:00 AM

Yakima Association of REALTORS

Check ticket price on event

_Save this event: How to buy a house in 2025__Share this event: How to buy a house in 2025_

## Points of Interest near Yakima

[Yakima Sportsman State Park](https://www.eventbrite.com/poi/wa--yakima/yakima-sportsman-state-park--uqYDj/) [Explore Yakima Sportsman State Park](https://www.eventbrite.com/poi/wa--yakima/yakima-sportsman-state-park--uqYDj/)

[Yakima Area Arboretum](https://www.eventbrite.com/poi/wa--yakima/yakima-area-arboretum--eMqCY/) [Explore Yakima Area Arboretum](https://www.eventbrite.com/poi/wa--yakima/yakima-area-arboretum--eMqCY/)

[Yakima Family Fun Center](https://www.eventbrite.com/poi/wa--yakima/yakima-family-fun-center--JKTCP/) [Explore Yakima Family Fun Center](https://www.eventbrite.com/poi/wa--yakima/yakima-family-fun-center--JKTCP/)

[Wilridge Vineyard Winery Distillery](https://www.eventbrite.com/poi/wa--yakima/wilridge-vineyard-winery-distillery--diy7S/) [Explore Wilridge Vineyard Winery Distillery](https://www.eventbrite.com/poi/wa--yakima/wilridge-vineyard-winery-distillery--diy7S/)

[Yakima Valley Museum](https://www.eventbrite.com/poi/wa--yakima/yakima-valley-museum--L8XY5/) [Explore Yakima Valley Museum](https://www.eventbrite.com/poi/wa--yakima/yakima-valley-museum--L8XY5/)

[Kana Winery](https://www.eventbrite.com/poi/wa--yakima/kana-winery--XwIHz/) [Explore Kana Winery](https://www.eventbrite.com/poi/wa--yakima/kana-winery--XwIHz/)

[Franklin Park](https://www.eventbrite.com/poi/wa--yakima/franklin-park--1tVNk/) [Explore Franklin Park](https://www.eventbrite.com/poi/wa--yakima/franklin-park--1tVNk/)

[Arboretum Botanical Garden](https://www.eventbrite.com/poi/wa--yakima/arboretum-botanical-garden--LJ91a/) [Explore Arboretum Botanical Garden](https://www.eventbrite.com/poi/wa--yakima/arboretum-botanical-garden--LJ91a/)

[Nerds Fun Center Lasertag](https://www.eventbrite.com/poi/wa--yakima/nerds-fun-center-lasertag--E4twm/) [Explore Nerds Fun Center Lasertag](https://www.eventbrite.com/poi/wa--yakima/nerds-fun-center-lasertag--E4twm/)

[Cowiche Canyon Uplands Trails](https://www.eventbrite.com/poi/wa--yakima/cowiche-canyon-uplands-trails--qAup2/) [Explore Cowiche Canyon Uplands Trails](https://www.eventbrite.com/poi/wa--yakima/cowiche-canyon-uplands-trails--qAup2/)

## Site Navigation

Use Eventbrite

- [Create Events](https://www.eventbrite.com/organizer/overview/)
- [Pricing](https://www.eventbrite.com/organizer/pricing/)
- [Event Marketing Platform](https://www.eventbrite.com/organizer/features/event-marketing-platform/)
- [Eventbrite Mobile Ticket App](https://www.eventbrite.com/l/eventbrite-app/)
- [Eventbrite Check-In App](https://www.eventbrite.com/organizer/features/organizer-check-in-app/)
- [Eventbrite App Marketplace](https://www.eventbrite.com/apps/)
- [Event Registration Software](https://www.eventbrite.com/organizer/features/registration-online/)
- [Community Guidelines](https://www.eventbrite.com/l/community-guidelines/)
- [FAQs](https://www.eventbrite.com/l/frequently-asked-questions/)
- [Sitemap](https://www.eventbrite.com/sitemap/)

Plan Events

- [Sell Tickets Online](https://www.eventbrite.com/organizer/features/sell-tickets/)
- [Performing Arts Ticketing Software](https://www.eventbrite.com/organizer/event-industry/performing-arts/)
- [Sell Concert Tickets Online](https://www.eventbrite.com/organizer/event-type/music-venues/)
- [Event Payment System](https://www.eventbrite.com/organizer/features/event-payment/)
- [Solutions for Professional Services](https://www.eventbrite.com/organizer/event-industry/professional-services/)
- [Event Management Software](https://www.eventbrite.com/organizer/features/event-management-software/)
- [Halloween Party Planning](https://www.eventbrite.com/organizer/event-type/halloween-event/)
- [Virtual Events Platform](https://www.eventbrite.com/organizer/event-type/virtual-events-platform/)
- [QR Codes for Event Check-In](https://www.eventbrite.com/organizer/features/how-to-use-qr-codes-for-events/)
- [Post your event online](https://www.eventbrite.com/organizer/features/post-events/)

Find Events

- [New Orleans Food & Drink Events](https://www.eventbrite.com/b/la--new-orleans/food-and-drink/)
- [San Francisco Holiday Events](https://www.eventbrite.com/b/ca--san-francisco/holiday/)
- [Tulum Music Events](https://www.eventbrite.com/b/mexico--tulum/music/)
- [Denver Hobby Events](https://www.eventbrite.com/b/co--denver/hobbies/)
- [Atlanta Pop Music Events](https://www.eventbrite.com/b/ga--atlanta/music/pop/)
- [New York Events](https://www.eventbrite.com/d/ny--new-york/events/)
- [Chicago Events](https://www.eventbrite.com/d/il--chicago/events/)
- [Events in Dallas Today](https://www.eventbrite.com/d/tx--dallas/events--today/)
- [Los Angeles Events](https://www.eventbrite.com/d/ca--los-angeles/events/)
- [Washington Events](https://www.eventbrite.com/d/dc--washington/events/)

Connect With Us

- [Contact Support](https://www.eventbrite.com/help/en-us/contact-us/)
- [Contact Sales](https://www.eventbrite.com/organizer/contact-sales/)
- [X](https://www.x.com/eventbritehelp)
- [Facebook](https://www.facebook.com/Eventbrite)
- [LinkedIn](https://www.linkedin.com/company/eventbrite)
- [Instagram](https://www.instagram.com/eventbrite)
- [TikTok](https://www.tiktok.com/@eventbrite)

© 2025 Eventbrite

- [How It Works](https://www.eventbrite.com/how-it-works)
- [Pricing](https://www.eventbrite.com/organizer/pricing/)
- [Contact Support](https://www.eventbrite.com/help/en-us/contact-us/)
- [About](https://www.eventbrite.com/about/)
- [Blog](https://www.eventbrite.com/blog/)
- [Help](https://www.eventbrite.com/help/en-us/)
- [Careers](https://www.eventbritecareers.com/)
- [Press](https://www.eventbrite.com/blog/press/)
- [Impact](https://www.eventbrite.com/l/impact/)
- [Investors](https://investor.eventbrite.com/overview/default.aspx)
- [Security](https://www.eventbrite.com/security/)
- [Developers](https://www.eventbrite.com/platform/)
- [Status](https://www.eventbritestatus.com/)
- [Terms](https://www.eventbrite.com/l/legalterms/)
- [Privacy](https://www.eventbrite.com/help/en-us/articles/460838/eventbrite-privacy-policy/)
- [Accessibility](https://www.eventbrite.com/l/accessibility/)
- [Cookies](https://www.eventbrite.com/help/en-us/articles/666792/eventbrite-cookie-policy/)
- [Manage Cookie Preferences](https://www.eventbrite.com/d/wa--yakima/events/#)

Locale

United StatesArgentinaAustraliaBelgiëBelgiqueBrasilCanada (EN)Canada (FR)ChileColombiaDenmarkDeutschlandEspañaFinlandFranceHong KongIrelandItaliaMéxicoNederlandNew ZealandÖsterreichPerúPortugalSchweizSingaporeSuisseSverigeUnited KingdomUnited States