<?php
// Redirect to the new dashboard
header('Location: /refactor/admin/dashboard');
exit;
?>